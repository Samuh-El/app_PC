"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    database: {
        //datos de conexion a db
        host: '190.107.177.34',
        user: 'producto_Felipe',
        password: ']wq-8xIFvf26',
        database: 'producto_chile'
        //datos de conexion a localhost
        // host:"localhost",  
        // user:"root", 
        // password:"",
        // database:"productoschile"
    }
};
