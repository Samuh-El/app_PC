"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class User {
    constructor(email, password) {
        this.email = email,
            this.password = password;
    }
}
exports.User = User;
